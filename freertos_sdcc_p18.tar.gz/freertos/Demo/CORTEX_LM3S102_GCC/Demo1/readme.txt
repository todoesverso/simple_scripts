Move these two fines into the Demo/CORTEX_LM3S102_GCC directory to run Demo 1.

See the port documentation on the www.FreeRTOS.org site for more information.
